// contoh pointer sebagai parameter fungsi
#include <iostream>
using namespace std;
void naikkan_nilai (int *x, int *y);
int main()
{
cout<<"================================================="<<endl;
cout<<"!  MODUL 6.10  pointer sebagai parameter fungsi !"<<endl;
cout<<"!-----------------------------------------------!"<<endl;
cout<<"!   Nama : Taufik Hidayat                       !"<<endl;
cout<<"!   NIM  : 202012027                            !"<<endl;
cout<<"================================================="<<endl;
 int a=3;
 int b=7;
 cout << "semula : a = "<< a<< " b = " << b << endl;
 naikkan_nilai(&a,&b);
 cout << "kini : a = "<< a << " b = " << b << endl;
}
void naikkan_nilai(int *x, int *y)
{
 *x = *x + 2;
 *y = *y + 2;
}
