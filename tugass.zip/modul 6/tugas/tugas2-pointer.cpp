// menukar isi dua string yang ditunjuk pointer
#include <iostream>
using namespace std;
char *nama1 = "hanif";
char *nama2 = "fathimah";
char *nama3 = "zahira";
int main()
{
cout<<"========================================="<<endl;
cout<<"!   Tugas 2 Pointer                     !"<<endl;
cout<<"!---------------------------------------!"<<endl;
cout<<"!   Nama : Taufik Hidayat               !"<<endl;
cout<<"!   NIM  : 202012027                    !"<<endl;
cout<<"========================================="<<endl;
 char *namax;
 cout << "semula : " << endl;
 cout << "nama1 -> " << nama1 << endl;
 cout << "nama2 -> " << nama2 << endl;
 cout << "nama3 -> " << nama3 << endl;
 // penukaran string yang ditunjuk oleh pointer nama1 dan nama2
 namax = nama1;
 nama1 = nama3;
 nama3 = nama2;
 nama2 = namax;
 cout << "kini : " << endl;
 cout << "nama1 -> " << nama1 << endl;
 cout << "nama2 -> " << nama2 << endl;
 cout << "nama3 -> " << nama3 << endl;
}
