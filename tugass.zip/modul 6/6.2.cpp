// Contoh pemakaian pointer yang salah
#include<iostream>
using namespace std;

int main()
{
cout<<"========================================="<<endl;
cout<<"!   MODUL 6.2 pointer yang salah        !"<<endl;
cout<<"!---------------------------------------!"<<endl;
cout<<"!   Nama : Taufik Hidayat               !"<<endl;
cout<<"!   NIM  : 202012027                    !"<<endl;
cout<<"========================================="<<endl;
 float *pu;
 float nu;
 int u = 1234;
 pu = &u; 
 // pernyataan ini salah
 // sebab pu adalah pointer float padahal u bertipe int
 nu = *pu;
 cout << "u = " << u << endl;
 cout << "nu = " << nu << endl;
}

