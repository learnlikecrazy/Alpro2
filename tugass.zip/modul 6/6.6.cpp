#include <iostream>
using namespace std;
int main()
{
cout<<"========================================="<<endl;
cout<<"! MODUL 6.6 pointer yang menunjuk string!"<<endl;
cout<<"!---------------------------------------!"<<endl;
cout<<"!   Nama : Taufik Hidayat               !"<<endl;
cout<<"!   NIM  : 202012027                    !"<<endl;
cout<<"========================================="<<endl;
 char *pkota = "YOGYAKARTA"; /* pkota menunjuk konstanta string
"YOGYAKARTA" */
 cout << pkota << endl;
}
