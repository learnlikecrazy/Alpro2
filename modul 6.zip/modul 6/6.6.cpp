#include <iostream>
using namespace std;
int main()
{
 char *pkota = "YOGYAKARTA"; /* pkota menunjuk konstanta string
"YOGYAKARTA" */
 cout << pkota << endl;
}
