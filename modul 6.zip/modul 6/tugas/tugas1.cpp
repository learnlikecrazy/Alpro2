#include <iostream>
#include <string.h>
#include <string>
using namespace std;
int main(){
	char data[] = "Pemrograman Dasar Turbo C";
	char *kata1 = &data[10];
	char *kata2 = &data[12];
	char *kata3 = &data[18];
	cout<<data;
	cout<<endl;
	cout<<kata2;
	cout<<endl;
	cout<<kata3;

}
